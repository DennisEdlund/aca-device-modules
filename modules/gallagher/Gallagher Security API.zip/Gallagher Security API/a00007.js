var a00007 =
[
    [ "CifStringDefault", "a00007.html#a06f52bd7c6692b28f011918ce84e2625", null ],
    [ "CifStringDefault", "a00007.html#a5e7801bd7cf8f2de7df56e7979f9eb16", null ],
    [ "OtherwiseValue", "a00007.html#ac8d26178a0b2aeb0e090c59a5c0e4ec6", null ],
    [ "UseDefault", "a00007.html#a8d86a3d82f008ca4e6151be608ac6140", null ],
    [ "Value", "a00007.html#ac0ffd9b51a1b0c48095d2bf4df6868fb", null ]
];