var namespaces =
[
    [ "Gallagher", "a00022.html", "a00022" ]
];