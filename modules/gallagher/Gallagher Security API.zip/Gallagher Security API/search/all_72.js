var searchData=
[
  ['reason',['Reason',['../a00008.html#a9c12abe978ceca0e7b6997ab4b41422d',1,'Gallagher.Security.WebService.ConnectionRefusedFault.Reason()'],['../a00012.html#a6b3c05709a53af2c258d031920af8bae',1,'Gallagher.Security.WebService.OperationFailedFault.Reason()']]]
];
