var searchData=
[
  ['usedefault',['UseDefault',['../a00004.html#ad13b6114b243432de5347c3ff8790167',1,'Gallagher.Security.WebService.CardholderInterface.CifDateTimeDefault.UseDefault()'],['../a00005.html#ad21be0f9bd661c90cbea50f7d10d8bc5',1,'Gallagher.Security.WebService.CardholderInterface.CifIntegerDefault.UseDefault()'],['../a00001.html#ab61d6af415690579922663201615d6bb',1,'Gallagher.Security.WebService.CardholderInterface.CifBooleanDefault.UseDefault()'],['../a00007.html#a8d86a3d82f008ca4e6151be608ac6140',1,'Gallagher.Security.WebService.CardholderInterface.CifStringDefault.UseDefault()']]]
];
