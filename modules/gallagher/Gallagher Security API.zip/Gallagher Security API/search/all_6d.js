var searchData=
[
  ['matchintimerange',['MatchInTimeRange',['../a00025.html#ac2660920f7f4d2979956c91b3b84031aa3ea6bfeb82b2c11b348fc0dc63a05f41',1,'Gallagher::Security::WebService::CardholderInterface']]],
  ['matchtimesexactly',['MatchTimesExactly',['../a00025.html#ac2660920f7f4d2979956c91b3b84031aa9303c0fb402eef596d1d7f2f4af8bc70',1,'Gallagher::Security::WebService::CardholderInterface']]]
];
