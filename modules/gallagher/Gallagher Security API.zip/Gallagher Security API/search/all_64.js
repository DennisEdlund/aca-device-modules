var searchData=
[
  ['disconnect',['Disconnect',['../a00011.html#a8e79243b27df08ac12e7c6bd7ad5db18',1,'Gallagher::Security::WebService::IWebService']]]
];
