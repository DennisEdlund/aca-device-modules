var a00006 =
[
    [ "CifIssueCardResult", "a00006.html#abbf613c68f66159eacff6b8096cf09c2", null ],
    [ "CardNumber", "a00006.html#ac54521dea35bd0b14d5fc5f2800765d2", null ],
    [ "WasCreated", "a00006.html#abb257bdab2e80112dc3f1a1cf7f105cb", null ]
];