var a00016 =
[
    [ "SessionToken", "a00016.html#a16f16dcd4db096b9486542c335df0d54", null ],
    [ "Equals", "a00016.html#aeda474e1564e75ed1e3bfcf0534c301e", null ],
    [ "GetHashCode", "a00016.html#ae8e880671f190cd17bd0be535342613b", null ],
    [ "ToString", "a00016.html#a159ca024c67ab4b772b38dbcf12b81e9", null ],
    [ "Value", "a00016.html#aa159ba423e58fc874c5af9a85ee2f1a6", null ]
];