var hierarchy =
[
    [ "Gallagher.Security.WebService.CardholderInterface.CifBooleanDefault", "a00001.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifCard", "a00002.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifCardholderPdfId", "a00003.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifDateTimeDefault", "a00004.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifIntegerDefault", "a00005.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifIssueCardResult", "a00006.html", null ],
    [ "Gallagher.Security.WebService.CardholderInterface.CifStringDefault", "a00007.html", null ],
    [ "Gallagher.Security.WebService.ConnectionRefusedFault", "a00008.html", null ],
    [ "Gallagher.Security.WebService.Id", "a00010.html", null ],
    [ "Gallagher.Security.WebService.IWebService", "a00011.html", [
      [ "Gallagher.Security.WebService.CardholderInterface.ICifWebService", "a00009.html", null ]
    ] ],
    [ "Gallagher.Security.WebService.OperationFailedFault", "a00012.html", null ],
    [ "Gallagher.Security.WebService.PdfValue", "a00015.html", [
      [ "Gallagher.Security.WebService.PdfGeneralValue", "a00013.html", null ],
      [ "Gallagher.Security.WebService.PdfImageValue", "a00014.html", null ]
    ] ],
    [ "Gallagher.Security.WebService.SessionToken", "a00016.html", null ],
    [ "Gallagher.Security.WebService.SessionTokenNotValidFault", "a00017.html", null ]
];