var a00005 =
[
    [ "CifIntegerDefault", "a00005.html#ad8bef6ebde87533af6a5f905067857cb", null ],
    [ "CifIntegerDefault", "a00005.html#ae5e5d159dfe3fd614da65e753d29953c", null ],
    [ "OtherwiseValue", "a00005.html#a7b984a541d8bfa6cf0e04067e70d8fae", null ],
    [ "UseDefault", "a00005.html#ad21be0f9bd661c90cbea50f7d10d8bc5", null ],
    [ "Value", "a00005.html#afc473bcf1db0ec4544378f1e083d1650", null ]
];