var a00025 =
[
    [ "ICifWebService", "a00009.html", "a00009" ],
    [ "CifDateTimeDefault", "a00004.html", "a00004" ],
    [ "CifIntegerDefault", "a00005.html", "a00005" ],
    [ "CifBooleanDefault", "a00001.html", "a00001" ],
    [ "CifStringDefault", "a00007.html", "a00007" ],
    [ "CifCardholderPdfId", "a00003.html", "a00003" ],
    [ "CifIssueCardResult", "a00006.html", "a00006" ],
    [ "CifCard", "a00002.html", "a00002" ]
];