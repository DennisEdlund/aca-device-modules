var a00015 =
[
    [ "PdfValue", "a00015.html#aa34c20ff8a32c88656db8169270070af", null ],
    [ "Create", "a00015.html#ac9e806dcd051b38ad36b6b6d7a115f49", null ],
    [ "Equals", "a00015.html#abf2f3b82b6337d5c42254b0a0f1adff4", null ],
    [ "GetHashCode", "a00015.html#a1b3ac7ecfeb0d6b9705f63f3ec8cac02", null ],
    [ "Name", "a00015.html#a118a41737b63fa7582609fab73bb2aee", null ],
    [ "Type", "a00015.html#a6f186b387d3ae8f7f1b683c7646716e1", null ]
];