var a00010 =
[
    [ "Id", "a00010.html#a1e26d0db00eb65103a84ac72f79bc96a", null ],
    [ "ToString", "a00010.html#a63a5009c0c33d54b3f2b1827f74902cc", null ],
    [ "Value", "a00010.html#ad807e5904168108f038078970c44c1f7", null ]
];