var a00011 =
[
    [ "Connect", "a00011.html#a5f96221406672a649598b4893ca85788", null ],
    [ "Disconnect", "a00011.html#a8e79243b27df08ac12e7c6bd7ad5db18", null ]
];