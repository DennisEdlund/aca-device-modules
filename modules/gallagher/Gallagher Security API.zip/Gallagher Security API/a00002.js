var a00002 =
[
    [ "CardNumber", "a00002.html#ab3504a03dad43713c554704c8f011001", null ],
    [ "CardType", "a00002.html#ae8e41eed7deebe161f04521e6c3d0a11", null ]
];