var a00004 =
[
    [ "CifDateTimeDefault", "a00004.html#a0226fea0a48b4e38d6e7ba0401a0fe3a", null ],
    [ "CifDateTimeDefault", "a00004.html#a37005abfe2ffd2fa77119d67faea1e34", null ],
    [ "OtherwiseValue", "a00004.html#a7a50f90370d64f14ae6b1fbb2b0113f8", null ],
    [ "UseDefault", "a00004.html#ad13b6114b243432de5347c3ff8790167", null ],
    [ "Value", "a00004.html#a839afac51009ae84b5adf6a3f2614307", null ]
];