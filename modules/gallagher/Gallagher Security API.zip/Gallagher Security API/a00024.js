var a00024 =
[
    [ "CardholderInterface", "a00025.html", "a00025" ],
    [ "ConnectionRefusedFault", "a00008.html", "a00008" ],
    [ "SessionTokenNotValidFault", "a00017.html", "a00017" ],
    [ "OperationFailedFault", "a00012.html", "a00012" ],
    [ "SessionToken", "a00016.html", "a00016" ],
    [ "Id", "a00010.html", "a00010" ],
    [ "PdfValue", "a00015.html", "a00015" ],
    [ "PdfGeneralValue", "a00013.html", "a00013" ],
    [ "PdfImageValue", "a00014.html", "a00014" ],
    [ "IWebService", "a00011.html", "a00011" ]
];