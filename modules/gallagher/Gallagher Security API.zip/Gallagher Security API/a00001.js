var a00001 =
[
    [ "CifBooleanDefault", "a00001.html#ae183e778cca95d0d259c0b2b030bf161", null ],
    [ "CifBooleanDefault", "a00001.html#a74715327871571b23b92fe1bd832854a", null ],
    [ "OtherwiseValue", "a00001.html#a1ca6ac72e0cddd999f465276f1feecdc", null ],
    [ "UseDefault", "a00001.html#ab61d6af415690579922663201615d6bb", null ],
    [ "Value", "a00001.html#a2a761522f9228298e2b7f24e89459d3b", null ]
];