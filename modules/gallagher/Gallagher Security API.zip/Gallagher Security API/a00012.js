var a00012 =
[
    [ "CulpritItemType", "a00012.html#a348b08120cea2af011b959450934ba35", null ],
    [ "CulpritOperation", "a00012.html#a44020a380216baed4cd46bccca0eafe8", null ],
    [ "Reason", "a00012.html#a6b3c05709a53af2c258d031920af8bae", null ]
];